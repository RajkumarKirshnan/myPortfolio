$(document).ready(function(){
    loadPage('intro');
    $("#nav-menu li.btn-grad").on('click',function(){
        resetMenu();
        $(this).addClass('active');
        loadPage($(this).attr('data-page'));
    });
});

function resetMenu(){
    $("#nav-menu li.btn-grad").each(function(index,ele){
        $(ele).removeClass('active');
    });
}
function loadPage(page){
    unloadPage(); 
    $("#"+page).css('display','grid');
}
function unloadPage(){
  var allPages = ["intro","education","experience","skill","awards"];
  $.each(allPages,function(index,data){
      $("#"+data).css('display','none');
  });
}
function animate(){

}
Highcharts.chart('container', {
    chart: {
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 2,
            beta: 10,
            depth: 50
        }
    },
    title: {
        text: 'Work Experience'
    },
    subtitle: {
        text: ''
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    xAxis: {
        categories: ['Tata Consultancy Services', 'Inexgen Games', 'Beyond Universe software solutions',
            'AEL Data services', 'Teledata informatics Pvt Ltd'
        ],
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px'
            }
        }
    },
    yAxis: {
        title: {
            text: null
        }
    },
    series: [{
        name: 'Experience',
        data: [5, 0.6, 1.10, 0.7, 2.5]
    }]
});
Highcharts.chart('container2', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Skill metrics'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y}/5</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Skill metrics',
        data: [
            ['html/html5', 4],
            ['css/css3', 4],
            ['javascript', 4],
            ['jQuery', 4],
            ['Bootstrap', 4],
            ['Angular', 3],
            ['GIT',3],
            ['AZURE',3],
            ['AGILE',3],
            ['Devops',3]
        ]
    }]
});